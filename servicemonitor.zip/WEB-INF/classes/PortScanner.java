/**
*	Disclaimer: The following code was modified from http://www.javalobby.org/servlet/JiveServlet/download/209-78689-92040943-5312/jscanner2.java
*/
import java.net.*;
import java.io.*;

public class PortScanner
{
        public boolean portStatus(String name,int port) {
			try{
			InetAddress host = InetAddress.getByName(name);
			return portStatus(host,port);
			}catch (Exception e){
				return false;
			}
	}	
        public boolean portStatus(InetAddress host,int port){
				try
				{
					Socket socket = new Socket(host, port);
					socket.close();
					return true;
				}	catch(IOException ex)	{
					return false;
				}
	}	
	public void scan(String name,int startPort, int endPort)
	{
			if (endPort < startPort) {
				int tmpPort = endPort;
				endPort = startPort;
				startPort = tmpPort;
			}
						
			for(int testPort = startPort; testPort <= endPort; testPort++)
			{
				boolean status=portStatus(name,testPort);
				if(status){
				System.out.println(name+" "+testPort+" up");
				}
			}
			
	}
	
	private String toText(byte ip[])
	{
		StringBuffer result = new StringBuffer();
		for(int i = 0; i < ip.length; i++)
		{
			if(i > 0)
				result.append(".");
			result.append(0xff & ip[i]);
		}
		return result.toString();
	}
	
	
	public static void main(String args[])
	{
		if(args.length!=3){
			System.out.println("Usage: java PortScanner hostname startport endport");
			System.exit(0);
		}	
			PortScanner ps=new PortScanner();
				ps.scan(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
	}
}
